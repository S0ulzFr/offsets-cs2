// Generated using https://github.com/a2x/cs2-dumper
// 2026-10-30 22:23:05.297711900 UTC

namespace CS2Dumper.Interfaces {
    // Module: animationsystem.dll
    public static class AnimationsystemDll {
        public const nint AnimationSystemUtils_001 = 0x83F6D8;
        public const nint AnimationSystem_001 = 0x8375F8;
    }
    // Module: client.dll
    public static class ClientDll {
        public const nint ClientBugBugServic001_Client = 0x2237760;
        public const nint ClientToolsInfo_001 = 0x2237730;
        public const nint EmptyWorldService001_Client = 0x221B160;
        public const nint GameClientExports001 = 0x22343D8;
        public const nint LegacyGameUI001 = 0x2244180;
        public const nint Source2Client002 = 0x25635A0;
        public const nint Source2ClientConfig001 = 0x24C0150;
        public const nint Source2ClientPrediction001 = 0x25697D0;
        public const nint Source2ClientUI001 = 0x2242900;
    }
    // Module: engine2.dll
    public static class Engine2Dll {
        public const nint BenchmarkService001 = 0x6BFCC0;
        public const nint BugBugService001 = 0x6BFDC0;
        public const nint BugService001 = 0x9790F0;
        public const nint ClientServerEngineLoopService_001 = 0x9BAAE0;
        public const nint ClientServerSharedHandleSystem001 = 0x9BA0F0;
        public const nint EngineGameUI001 = 0x6BD720;
        public const nint EngineServiceMgr001 = 0x9BA3B0;
        public const nint GameEventSystemClientV001 = 0x9BA690;
        public const nint GameEventSystemServerV001 = 0x9BA7C0;
        public const nint GameResourceServiceClientV001 = 0x6BFE00;
        public const nint GameResourceServiceServerV001 = 0x6BFE60;
        public const nint GameUIService_001 = 0x979540;
        public const nint HostStateMgr001 = 0x6C02A0;
        public const nint INETSUPPORT_001 = 0x6B8C70;
        public const nint InputService_001 = 0x979820;
        public const nint KeyValueCache001 = 0x6C0350;
        public const nint MapListService_001 = 0x9B8690;
        public const nint NetworkClientService_001 = 0x9B8820;
        public const nint NetworkP2PService_001 = 0x9B8B60;
        public const nint NetworkServerService_001 = 0x9B8D10;
        public const nint NetworkService_001 = 0x6BFFD0;
        public const nint RenderService_001 = 0x9B8F80;
        public const nint ScreenshotService001 = 0x9B9240;
        public const nint SimpleEngineLoopService_001 = 0x6C03B0;
        public const nint SoundService_001 = 0x9B93F0;
        public const nint Source2EngineToClient001 = 0x6BD030;
        public const nint Source2EngineToClientStringTable001 = 0x6BD090;
        public const nint Source2EngineToServer001 = 0x6BD108;
        public const nint Source2EngineToServerStringTable001 = 0x6BD130;
        public const nint SplitScreenService_001 = 0x6C0010;
        public const nint StatsService_001 = 0x9B9930;
        public const nint ToolService_001 = 0x6C0110;
        public const nint VENGINE_GAMEUIFUNCS_VERSION005 = 0x6BD7B0;
        public const nint VProfService_001 = 0x6C0150;
    }
    // Module: filesystem_stdio.dll
    public static class FilesystemStdioDll {
        public const nint VAsyncFileSystem2_001 = 0x214610;
        public const nint VFileSystem017 = 0x2143D0;
    }
    // Module: host.dll
    public static class HostDll {
        public const nint DebugDrawQueueManager001 = 0x13FF70;
        public const nint GameModelInfo001 = 0x13FFB0;
        public const nint GameSystem2HostHook = 0x13FFF0;
        public const nint HostUtils001 = 0x14F900;
        public const nint PredictionDiffManager001 = 0x140100;
        public const nint SaveRestoreDataVersion001 = 0x140230;
        public const nint SinglePlayerSharedMemory001 = 0x140260;
        public const nint Source2Host001 = 0x1402D0;
    }
    // Module: imemanager.dll
    public static class ImemanagerDll {
        public const nint IMEManager001 = 0x37AA0;
    }
    // Module: inputsystem.dll
    public static class InputsystemDll {
        public const nint InputStackSystemVersion001 = 0x44E90;
        public const nint InputSystemVersion001 = 0x46BC0;
    }
    // Module: localize.dll
    public static class LocalizeDll {
        public const nint Localize_001 = 0x59120;
    }
    // Module: matchmaking.dll
    public static class MatchmakingDll {
        public const nint GameTypes001 = 0x1B0FD0;
        public const nint MATCHFRAMEWORK_001 = 0x1B90A0;
    }
    // Module: materialsystem2.dll
    public static class Materialsystem2Dll {
        public const nint FontManager_001 = 0x1638E0;
        public const nint MaterialUtils_001 = 0x14BD30;
        public const nint PostProcessingSystem_001 = 0x14BC60;
        public const nint TextLayout_001 = 0x14BCC0;
        public const nint VMaterialSystem2_001 = 0x163530;
    }
    // Module: meshsystem.dll
    public static class MeshsystemDll {
        public const nint MeshSystem001 = 0x180AB0;
    }
    // Module: navsystem.dll
    public static class NavsystemDll {
        public const nint NavSystem001 = 0x12C000;
    }
    // Module: networksystem.dll
    public static class NetworksystemDll {
        public const nint FlattenedSerializersVersion001 = 0x277A50;
        public const nint NetworkMessagesVersion001 = 0x2A3F30;
        public const nint NetworkSystemVersion001 = 0x2911A0;
        public const nint SerializedEntitiesVersion001 = 0x291290;
    }
    // Module: panorama.dll
    public static class PanoramaDll {
        public const nint PanoramaUIEngine001 = 0x5895F0;
    }
    // Module: panorama_text_pango.dll
    public static class PanoramaTextPangoDll {
        public const nint PanoramaTextServices001 = 0x2BA9D0;
    }
    // Module: panoramauiclient.dll
    public static class PanoramauiclientDll {
        public const nint PanoramaUIClient001 = 0x270710;
    }
    // Module: particles.dll
    public static class ParticlesDll {
        public const nint ParticleSystemMgr003 = 0x65ADD0;
    }
    // Module: pulse_system.dll
    public static class PulseSystemDll {
        public const nint IPulseSystem_001 = 0x238120;
    }
    // Module: rendersystemdx11.dll
    public static class Rendersystemdx11Dll {
        public const nint RenderDeviceMgr001 = 0x4342F0;
        public const nint RenderUtils_001 = 0x434BD0;
        public const nint VRenderDeviceMgrBackdoor001 = 0x434390;
    }
    // Module: resourcesystem.dll
    public static class ResourcesystemDll {
        public const nint ResourceSystem013 = 0x89230;
    }
    // Module: scenefilecache.dll
    public static class ScenefilecacheDll {
        public const nint ResponseRulesCache001 = 0x11D350;
        public const nint SceneFileCache002 = 0x11D478;
    }
    // Module: scenesystem.dll
    public static class ScenesystemDll {
        public const nint RenderingPipelines_001 = 0x6759F0;
        public const nint SceneSystem_002 = 0x91FB20;
        public const nint SceneUtils_001 = 0x676750;
    }
    // Module: schemasystem.dll
    public static class SchemasystemDll {
        public const nint SchemaSystem_001 = 0x76710;
    }
    // Module: server.dll
    public static class ServerDll {
        public const nint EmptyWorldService001_Server = 0x1E110C0;
        public const nint EntitySubclassUtilsV001 = 0x1DC0C40;
        public const nint NavGameTest001 = 0x1E58D38;
        public const nint ServerToolsInfo_001 = 0x1E37C38;
        public const nint Source2GameClients001 = 0x1E37160;
        public const nint Source2GameDirector001 = 0x1FA1510;
        public const nint Source2GameEntities001 = 0x1E373E0;
        public const nint Source2Server001 = 0x1E37220;
        public const nint Source2ServerConfig001 = 0x211CDE8;
        public const nint customnavsystem001 = 0x1DAE558;
    }
    // Module: soundsystem.dll
    public static class SoundsystemDll {
        public const nint SoundBugBugService001_Client = 0x532C40;
        public const nint SoundOpSystem001 = 0x532B20;
        public const nint SoundOpSystemEdit001 = 0x532A30;
        public const nint SoundSystem001 = 0x532420;
        public const nint VMixEditTool001 = 0x5941C1F;
    }
    // Module: steamaudio.dll
    public static class SteamaudioDll {
        public const nint SteamAudio001 = 0x35C1A0;
    }
    // Module: tier0.dll
    public static class Tier0Dll {
        public const nint TestScriptMgr001 = 0x3A1960;
        public const nint VEngineCvar007 = 0x3AC670;
        public const nint VProcessUtils002 = 0x3A1820;
        public const nint VStringTokenSystem001 = 0x3D3300;
    }
    // Module: v8system.dll
    public static class V8systemDll {
        public const nint Source2V8System001 = 0x34790;
    }
    // Module: vphysics2.dll
    public static class Vphysics2Dll {
        public const nint VPhysics2_Interface_001 = 0x460E60;
    }
    // Module: vscript.dll
    public static class VscriptDll {
        public const nint VScriptManager010 = 0x13E430;
    }
    // Module: worldrenderer.dll
    public static class WorldrendererDll {
        public const nint WorldRendererMgr001 = 0x236D40;
    }
}
