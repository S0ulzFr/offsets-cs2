// Generated using https://github.com/a2x/cs2-dumper
// 2026-10-30 22:23:05.297711900 UTC

#pragma once

#include <cstddef>
#include <cstdint>

namespace cs2_dumper {
    namespace interfaces {
        // Module: animationsystem.dll
        namespace animationsystem_dll {
            constexpr std::ptrdiff_t AnimationSystemUtils_001 = 0x83F6D8;
            constexpr std::ptrdiff_t AnimationSystem_001 = 0x8375F8;
        }
        // Module: client.dll
        namespace client_dll {
            constexpr std::ptrdiff_t ClientBugBugServic001_Client = 0x2237760;
            constexpr std::ptrdiff_t ClientToolsInfo_001 = 0x2237730;
            constexpr std::ptrdiff_t EmptyWorldService001_Client = 0x221B160;
            constexpr std::ptrdiff_t GameClientExports001 = 0x22343D8;
            constexpr std::ptrdiff_t LegacyGameUI001 = 0x2244180;
            constexpr std::ptrdiff_t Source2Client002 = 0x25635A0;
            constexpr std::ptrdiff_t Source2ClientConfig001 = 0x24C0150;
            constexpr std::ptrdiff_t Source2ClientPrediction001 = 0x25697D0;
            constexpr std::ptrdiff_t Source2ClientUI001 = 0x2242900;
        }
        // Module: engine2.dll
        namespace engine2_dll {
            constexpr std::ptrdiff_t BenchmarkService001 = 0x6BFCC0;
            constexpr std::ptrdiff_t BugBugService001 = 0x6BFDC0;
            constexpr std::ptrdiff_t BugService001 = 0x9790F0;
            constexpr std::ptrdiff_t ClientServerEngineLoopService_001 = 0x9BAAE0;
            constexpr std::ptrdiff_t ClientServerSharedHandleSystem001 = 0x9BA0F0;
            constexpr std::ptrdiff_t EngineGameUI001 = 0x6BD720;
            constexpr std::ptrdiff_t EngineServiceMgr001 = 0x9BA3B0;
            constexpr std::ptrdiff_t GameEventSystemClientV001 = 0x9BA690;
            constexpr std::ptrdiff_t GameEventSystemServerV001 = 0x9BA7C0;
            constexpr std::ptrdiff_t GameResourceServiceClientV001 = 0x6BFE00;
            constexpr std::ptrdiff_t GameResourceServiceServerV001 = 0x6BFE60;
            constexpr std::ptrdiff_t GameUIService_001 = 0x979540;
            constexpr std::ptrdiff_t HostStateMgr001 = 0x6C02A0;
            constexpr std::ptrdiff_t INETSUPPORT_001 = 0x6B8C70;
            constexpr std::ptrdiff_t InputService_001 = 0x979820;
            constexpr std::ptrdiff_t KeyValueCache001 = 0x6C0350;
            constexpr std::ptrdiff_t MapListService_001 = 0x9B8690;
            constexpr std::ptrdiff_t NetworkClientService_001 = 0x9B8820;
            constexpr std::ptrdiff_t NetworkP2PService_001 = 0x9B8B60;
            constexpr std::ptrdiff_t NetworkServerService_001 = 0x9B8D10;
            constexpr std::ptrdiff_t NetworkService_001 = 0x6BFFD0;
            constexpr std::ptrdiff_t RenderService_001 = 0x9B8F80;
            constexpr std::ptrdiff_t ScreenshotService001 = 0x9B9240;
            constexpr std::ptrdiff_t SimpleEngineLoopService_001 = 0x6C03B0;
            constexpr std::ptrdiff_t SoundService_001 = 0x9B93F0;
            constexpr std::ptrdiff_t Source2EngineToClient001 = 0x6BD030;
            constexpr std::ptrdiff_t Source2EngineToClientStringTable001 = 0x6BD090;
            constexpr std::ptrdiff_t Source2EngineToServer001 = 0x6BD108;
            constexpr std::ptrdiff_t Source2EngineToServerStringTable001 = 0x6BD130;
            constexpr std::ptrdiff_t SplitScreenService_001 = 0x6C0010;
            constexpr std::ptrdiff_t StatsService_001 = 0x9B9930;
            constexpr std::ptrdiff_t ToolService_001 = 0x6C0110;
            constexpr std::ptrdiff_t VENGINE_GAMEUIFUNCS_VERSION005 = 0x6BD7B0;
            constexpr std::ptrdiff_t VProfService_001 = 0x6C0150;
        }
        // Module: filesystem_stdio.dll
        namespace filesystem_stdio_dll {
            constexpr std::ptrdiff_t VAsyncFileSystem2_001 = 0x214610;
            constexpr std::ptrdiff_t VFileSystem017 = 0x2143D0;
        }
        // Module: host.dll
        namespace host_dll {
            constexpr std::ptrdiff_t DebugDrawQueueManager001 = 0x13FF70;
            constexpr std::ptrdiff_t GameModelInfo001 = 0x13FFB0;
            constexpr std::ptrdiff_t GameSystem2HostHook = 0x13FFF0;
            constexpr std::ptrdiff_t HostUtils001 = 0x14F900;
            constexpr std::ptrdiff_t PredictionDiffManager001 = 0x140100;
            constexpr std::ptrdiff_t SaveRestoreDataVersion001 = 0x140230;
            constexpr std::ptrdiff_t SinglePlayerSharedMemory001 = 0x140260;
            constexpr std::ptrdiff_t Source2Host001 = 0x1402D0;
        }
        // Module: imemanager.dll
        namespace imemanager_dll {
            constexpr std::ptrdiff_t IMEManager001 = 0x37AA0;
        }
        // Module: inputsystem.dll
        namespace inputsystem_dll {
            constexpr std::ptrdiff_t InputStackSystemVersion001 = 0x44E90;
            constexpr std::ptrdiff_t InputSystemVersion001 = 0x46BC0;
        }
        // Module: localize.dll
        namespace localize_dll {
            constexpr std::ptrdiff_t Localize_001 = 0x59120;
        }
        // Module: matchmaking.dll
        namespace matchmaking_dll {
            constexpr std::ptrdiff_t GameTypes001 = 0x1B0FD0;
            constexpr std::ptrdiff_t MATCHFRAMEWORK_001 = 0x1B90A0;
        }
        // Module: materialsystem2.dll
        namespace materialsystem2_dll {
            constexpr std::ptrdiff_t FontManager_001 = 0x1638E0;
            constexpr std::ptrdiff_t MaterialUtils_001 = 0x14BD30;
            constexpr std::ptrdiff_t PostProcessingSystem_001 = 0x14BC60;
            constexpr std::ptrdiff_t TextLayout_001 = 0x14BCC0;
            constexpr std::ptrdiff_t VMaterialSystem2_001 = 0x163530;
        }
        // Module: meshsystem.dll
        namespace meshsystem_dll {
            constexpr std::ptrdiff_t MeshSystem001 = 0x180AB0;
        }
        // Module: navsystem.dll
        namespace navsystem_dll {
            constexpr std::ptrdiff_t NavSystem001 = 0x12C000;
        }
        // Module: networksystem.dll
        namespace networksystem_dll {
            constexpr std::ptrdiff_t FlattenedSerializersVersion001 = 0x277A50;
            constexpr std::ptrdiff_t NetworkMessagesVersion001 = 0x2A3F30;
            constexpr std::ptrdiff_t NetworkSystemVersion001 = 0x2911A0;
            constexpr std::ptrdiff_t SerializedEntitiesVersion001 = 0x291290;
        }
        // Module: panorama.dll
        namespace panorama_dll {
            constexpr std::ptrdiff_t PanoramaUIEngine001 = 0x5895F0;
        }
        // Module: panorama_text_pango.dll
        namespace panorama_text_pango_dll {
            constexpr std::ptrdiff_t PanoramaTextServices001 = 0x2BA9D0;
        }
        // Module: panoramauiclient.dll
        namespace panoramauiclient_dll {
            constexpr std::ptrdiff_t PanoramaUIClient001 = 0x270710;
        }
        // Module: particles.dll
        namespace particles_dll {
            constexpr std::ptrdiff_t ParticleSystemMgr003 = 0x65ADD0;
        }
        // Module: pulse_system.dll
        namespace pulse_system_dll {
            constexpr std::ptrdiff_t IPulseSystem_001 = 0x238120;
        }
        // Module: rendersystemdx11.dll
        namespace rendersystemdx11_dll {
            constexpr std::ptrdiff_t RenderDeviceMgr001 = 0x4342F0;
            constexpr std::ptrdiff_t RenderUtils_001 = 0x434BD0;
            constexpr std::ptrdiff_t VRenderDeviceMgrBackdoor001 = 0x434390;
        }
        // Module: resourcesystem.dll
        namespace resourcesystem_dll {
            constexpr std::ptrdiff_t ResourceSystem013 = 0x89230;
        }
        // Module: scenefilecache.dll
        namespace scenefilecache_dll {
            constexpr std::ptrdiff_t ResponseRulesCache001 = 0x11D350;
            constexpr std::ptrdiff_t SceneFileCache002 = 0x11D478;
        }
        // Module: scenesystem.dll
        namespace scenesystem_dll {
            constexpr std::ptrdiff_t RenderingPipelines_001 = 0x6759F0;
            constexpr std::ptrdiff_t SceneSystem_002 = 0x91FB20;
            constexpr std::ptrdiff_t SceneUtils_001 = 0x676750;
        }
        // Module: schemasystem.dll
        namespace schemasystem_dll {
            constexpr std::ptrdiff_t SchemaSystem_001 = 0x76710;
        }
        // Module: server.dll
        namespace server_dll {
            constexpr std::ptrdiff_t EmptyWorldService001_Server = 0x1E110C0;
            constexpr std::ptrdiff_t EntitySubclassUtilsV001 = 0x1DC0C40;
            constexpr std::ptrdiff_t NavGameTest001 = 0x1E58D38;
            constexpr std::ptrdiff_t ServerToolsInfo_001 = 0x1E37C38;
            constexpr std::ptrdiff_t Source2GameClients001 = 0x1E37160;
            constexpr std::ptrdiff_t Source2GameDirector001 = 0x1FA1510;
            constexpr std::ptrdiff_t Source2GameEntities001 = 0x1E373E0;
            constexpr std::ptrdiff_t Source2Server001 = 0x1E37220;
            constexpr std::ptrdiff_t Source2ServerConfig001 = 0x211CDE8;
            constexpr std::ptrdiff_t customnavsystem001 = 0x1DAE558;
        }
        // Module: soundsystem.dll
        namespace soundsystem_dll {
            constexpr std::ptrdiff_t SoundBugBugService001_Client = 0x532C40;
            constexpr std::ptrdiff_t SoundOpSystem001 = 0x532B20;
            constexpr std::ptrdiff_t SoundOpSystemEdit001 = 0x532A30;
            constexpr std::ptrdiff_t SoundSystem001 = 0x532420;
            constexpr std::ptrdiff_t VMixEditTool001 = 0x5941C1F;
        }
        // Module: steamaudio.dll
        namespace steamaudio_dll {
            constexpr std::ptrdiff_t SteamAudio001 = 0x35C1A0;
        }
        // Module: tier0.dll
        namespace tier0_dll {
            constexpr std::ptrdiff_t TestScriptMgr001 = 0x3A1960;
            constexpr std::ptrdiff_t VEngineCvar007 = 0x3AC670;
            constexpr std::ptrdiff_t VProcessUtils002 = 0x3A1820;
            constexpr std::ptrdiff_t VStringTokenSystem001 = 0x3D3300;
        }
        // Module: v8system.dll
        namespace v8system_dll {
            constexpr std::ptrdiff_t Source2V8System001 = 0x34790;
        }
        // Module: vphysics2.dll
        namespace vphysics2_dll {
            constexpr std::ptrdiff_t VPhysics2_Interface_001 = 0x460E60;
        }
        // Module: vscript.dll
        namespace vscript_dll {
            constexpr std::ptrdiff_t VScriptManager010 = 0x13E430;
        }
        // Module: worldrenderer.dll
        namespace worldrenderer_dll {
            constexpr std::ptrdiff_t WorldRendererMgr001 = 0x236D40;
        }
    }
}
